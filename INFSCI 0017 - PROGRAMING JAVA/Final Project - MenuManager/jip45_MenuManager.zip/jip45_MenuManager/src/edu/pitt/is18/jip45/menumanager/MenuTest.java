package edu.pitt.is18.jip45.menumanager;

import java.util.ArrayList;

public class MenuTest {
    public static void main(String[] args) {

        String dishes = "/Users/pangjing/IdeaProjects/ProgramJavaCourse/Assignments/jip45_FinalProject/jip45_MenuManager/data/dishes.txt";
        String output = "/Users/pangjing/IdeaProjects/ProgramJavaCourse/Assignments/jip45_FinalProject/jip45_MenuManager/data/menus.txt";
        MenuManager randomize = new MenuManager(dishes);
        //Menu myMenu = randomize.maxCaloriesMenu("Random Menu");
        //System.out.println(myMenu.description() + "\nTotal calories: " + myMenu.totalCalories());

        ArrayList<Menu> list = new ArrayList<>();
        list.add(randomize.randomMenu("random"));
        list.add(randomize.minCaloriesMenu("min"));
        list.add(randomize.maxCaloriesMenu("max"));

    }
}
