package edu.pitt.is18.jip45.menumanager;

/**
 * Class Dessert extends MenuItem
 *
 * @author Jing Pang
 * created: 10/27/2018
 * updated: 11/25/2018
 */
public class Dessert extends MenuItem {

    /**
     * Constructor Dessert(String, String, int, double)
     *
     * @param name  a String
     * @param desc  a String
     * @param cal   an integer number
     * @param price an double number
     */
    public Dessert(String name, String desc, int cal, double price) {

        super(name, desc, cal, price);
    }

}
