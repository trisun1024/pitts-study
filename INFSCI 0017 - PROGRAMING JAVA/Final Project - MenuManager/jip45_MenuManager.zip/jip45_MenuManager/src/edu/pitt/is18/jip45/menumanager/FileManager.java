package edu.pitt.is18.jip45.menumanager;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Class FileManager
 *
 * @author Jing Pang
 * created: 11/08/2018
 * updated: 11/25/2018
 */
public class FileManager {

    /**
     * Method readItems(String)
     * Create a file reader to read the file from the system, and write into a ArrayList to store them.
     * In order to distinguish which type of menuitem is written, using the second option as instructor to determine
     * which kind of menuitem should be created.
     *
     * @param fileName a String
     * @return an ArrayList of MenuItem read from a file
     */
    public static ArrayList<MenuItem> readItems(String fileName) {
        // create new MenuItem ArrayList
        ArrayList myMenuItem = new ArrayList();

		/* the following reads in the MenuItem from the appropriate file, splitting the lines
			into the various parameters based on the characters signaling the split, before
			adding a new entree to the ArrayList with all the parameters; exceptions are
			also handled */
        try {
            FileReader fr = new FileReader(fileName);
            BufferedReader br = new BufferedReader(fr);
            String line;
            line = br.readLine();
            do {
                String[] name = line.split("@@");
                if (name[1].equals("entree")) {
                    myMenuItem.add(new Entree(name[0], name[2], Integer.parseInt(name[3]), Double.parseDouble(name[4])));
                } else if (name[1].equals("side")) {
                    myMenuItem.add(new Side(name[0], name[2], Integer.parseInt(name[3]), Double.parseDouble(name[4])));
                } else if (name[1].equals("salad")) {
                    myMenuItem.add(new Salad(name[0], name[2], Integer.parseInt(name[3]), Double.parseDouble(name[4])));
                } else if (name[1].equals("dessert")) {
                    myMenuItem.add(new Dessert(name[0], name[2], Integer.parseInt(name[3]), Double.parseDouble(name[4])));
                }
            } while ((line = br.readLine()) != null);
            br.close();
            fr.close();
        } catch (IOException e) {
            System.out.println("File error!");
        }

        return myMenuItem;
    }

    /**
     * Method writeMenu(String, ArrayList)
     * Create a menu
     *
     * @param fileName a String
     * @param menus    a ArrayList<Menu></Menu>
     */
    public static void writeMenu(String fileName, ArrayList<Menu> menus) {

        try {
            FileWriter fw = new FileWriter(fileName);
            BufferedWriter bw = new BufferedWriter(fw);
            for (int i = 0; i < menus.size(); i++) {
                double totalPrice = 0.0;
                if (menus.get(i).getMenuEntree() != null) totalPrice += menus.get(i).totalPrice();
                if (menus.get(i).getMenuSide() != null) totalPrice += menus.get(i).totalPrice();
                if (menus.get(i).getMenuSalad() != null) totalPrice += menus.get(i).totalPrice();
                if (menus.get(i).getMenuDessert() != null) totalPrice += menus.get(i).totalPrice();
                String myMenu = "----------------------- " +
                        "\nMENU:    ";
                if (menus.get(i) != null) {
                    myMenu += menus.get(i).getMenuName()
                            + "\n" + menus.get(i).description()
                            + "\nCalories: " + menus.get(i).totalCalories()
                            + "\nPrice: " + menus.get(i).totalPrice();
                }
                bw.write(myMenu);
                bw.newLine();
            }
            bw.close();
            fw.close();
        } catch (IOException e) {
            System.out.println("File error!");
        }
    }

}
