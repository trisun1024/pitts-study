package edu.pitt.is18.jip45.menumanager;

/**
 * Class Side extends MenuItem
 *
 * @author Jing Pang
 * created: 10/27/2018
 * version: 11/25/2018
 */

public class Side extends MenuItem {
    /**
     * Constructor Side(String, String, int, double)
     *
     * @param name        a String
     * @param description a String
     * @param calories    an integer number
     * @param price       an double number
     */
    public Side(String name, String description, int calories, double price) {
        super(name, description, calories, price);
    }

}
