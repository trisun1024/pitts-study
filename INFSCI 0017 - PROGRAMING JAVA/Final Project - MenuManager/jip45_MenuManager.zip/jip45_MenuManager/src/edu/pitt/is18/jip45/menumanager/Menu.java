package edu.pitt.is18.jip45.menumanager;

/**
 * Class Menu
 *
 * @author Jing Pang
 * created: 10/27/2018
 */
@SuppressWarnings("ALL")
public class Menu {

    private String name;
    private Entree entree;
    private Salad salad;
    private Side side;
    private Dessert dessert;

    /**
     * Constructor Menu(String)
     *
     * @param name a String
     */
    public Menu(String name) {
        this.name = name;
        this.entree = null;
        this.salad = null;
        this.side = null;
        this.dessert = null;
    }

    /**
     * Constructor Menu(String, Entree, Side)
     *
     * @param name   a String
     * @param entree an Entree
     * @param side   a Side
     */
    public Menu(String name, Entree entree, Side side) {
        this.name = name;
        this.entree = entree;
        this.salad = null;
        this.side = side;
        this.dessert = null;
    }

    /**
     * Constructor Menu(String, Entree, Side, Salad, Dessert)
     *
     * @param name    a String
     * @param entree  an Entree
     * @param side    a Side
     * @param salad   a Salad
     * @param dessert a Dessert
     */
    public Menu(String name, Entree entree, Side side, Salad salad, Dessert dessert) {
        this.name = name;
        this.entree = entree;
        this.salad = salad;
        this.side = side;
        this.dessert = dessert;
    }

    /**
     * Method description
     * Combine all the information in the specific menu with certain customized form.
     * To prevent the null value of menuitem, it assign the null value to a outcome string N/A
     *
     * @return a complete description of the existing
     * menu items including the names and descriptions
     */
    public String description() {

        String menuDescription = "";

        if (entree != null) {
            menuDescription = menuDescription + "Entree: " + entree.getName() + "\n" + entree.getDescription();
        } else {
            menuDescription = menuDescription + "\nEntree: N/A";
        }

        if (side != null) {
            menuDescription = menuDescription + "\nSide: " + side.getName() + "\n" + side.getDescription();
        } else {
            menuDescription = menuDescription + "\nSide: N/A";
        }

        if (salad != null) {
            menuDescription = menuDescription + "\nSalad: " + salad.getName() + "\n" + salad.getDescription();
        } else {
            menuDescription = menuDescription + "\nSalad: N/A";
        }

        if (dessert != null) {
            menuDescription = menuDescription + "\nDessert: " + dessert.getName() + "\n" + dessert.getDescription();
        } else {
            menuDescription = menuDescription + "\nDessert: N/A";
        }

        return menuDescription;
    }

    /**
     * Method totalCalories
     * Build a method to calculate the total calorie of whole menu.
     *
     * @return the sum of calories of all menu items
     */
    public int totalCalories() {

        int sumCals = 0;

        if (entree != null) {
            sumCals += this.entree.getCalories();
        }
        if (side != null) {
            sumCals += this.side.getCalories();
        }
        if (salad != null) {
            sumCals += this.salad.getCalories();
        }
        if (dessert != null) {
            sumCals += this.dessert.getCalories();
        }

        return sumCals;
    }

    /**
     * Method totalPrice
     * Build a method to calculate the total price of whole menu.
     *
     * @return the sum of calories of all menu items
     */
    public double totalPrice() {

        int sumPrice = 0;

        if (entree != null) {
            sumPrice += this.entree.getPrice();
        }
        if (side != null) {
            sumPrice += this.side.getPrice();
        }
        if (salad != null) {
            sumPrice += this.salad.getPrice();
        }
        if (dessert != null) {
            sumPrice += this.dessert.getPrice();
        }

        return sumPrice;
    }

    // Override toString() in order to return the Menu name.

    /**
     * Method toString()
     * A return of menu's name
     *
     * @return a String
     */
    @Override
    public String toString() {

        return name;
    }

    /**
     * setMenuName(String)
     *
     * @param name a menu name
     */
    // The following are getters and setters for the variables defined above.
    public void setMenuName(String name) {
        this.name = name;
    }

    /**
     * setMenuEntree(Entree)
     *
     * @param entree a Entree
     */
    public void setMenuEntree(Entree entree) {
        this.entree = entree;
    }

    /**
     * setMenuSalad(Salad)
     *
     * @param salad a Salad
     */
    public void setMenuSalad(Salad salad) {
        this.salad = salad;
    }

    /**
     * setMenuSide(Side)
     *
     * @param side a Side
     */

    public void setMenuSide(Side side) {
        this.side = side;
    }

    /**
     * setMenuDessert(Dessert)
     *
     * @param dessert a Dessert
     */
    public void setMenuDessert(Dessert dessert) {
        this.dessert = dessert;
    }

    /**
     * getMenuName()
     *
     * @return a String
     */
    public String getMenuName() {
        return name;
    }

    /**
     * getMenuEntree
     *
     * @return a Entree
     */
    public Entree getMenuEntree() {
        return entree;
    }

    /**
     * getMenuSide
     *
     * @return a Side
     */
    public Side getMenuSide() {
        return side;
    }

    /**
     * getMenuSalad
     *
     * @return a Salad
     */
    public Salad getMenuSalad() {
        return salad;
    }

    /**
     * getMenuDessert
     *
     * @return a Dessert
     */
    public Dessert getMenuDessert() {
        return dessert;
    }

}
