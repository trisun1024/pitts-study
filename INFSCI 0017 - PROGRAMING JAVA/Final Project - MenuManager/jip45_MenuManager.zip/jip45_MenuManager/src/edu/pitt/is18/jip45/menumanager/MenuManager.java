package edu.pitt.is18.jip45.menumanager;

import java.util.*;

/**
 * Class MenuManager
 *
 * @author Jing Pang
 * created: 11/25/2018
 */
public class MenuManager {

    private ArrayList<Entree> entrees = new ArrayList<>();
    private ArrayList<Side> sides = new ArrayList<>();
    private ArrayList<Salad> salads = new ArrayList<>();
    private ArrayList<Dessert> desserts = new ArrayList<>();

    /**
     * Constructor MenuManager(String)
     *
     * @param dishesFile a String
     */
    public MenuManager(String dishesFile) {

        ArrayList<MenuItem> menuItems = FileManager.readItems(dishesFile);
        Iterator itr = menuItems.iterator();
        while (itr.hasNext()) {
            Object obj = itr.next();
            if (obj instanceof Entree) {
                Entree temp = (Entree) obj;
                entrees.add(temp);
            } else if (obj instanceof Side) {
                Side temp = (Side) obj;
                sides.add(temp);
            } else if (obj instanceof Salad) {
                Salad temp = (Salad) obj;
                salads.add(temp);
            } else if (obj instanceof Dessert) {
                Dessert temp = (Dessert) obj;
                desserts.add(temp);
            }
        }
    }

    /**
     * Method randomMenu
     *
     * @param name a String
     * @return the randomized menu
     */
    public Menu randomMenu(String name) {

        Menu randMenu = new Menu(name);    // menu created and given title

        for (int i = 0; i < 4; i++) {
            /* The code below generates a random number between 0 and 3 (the # of lines in each
             * text file is 4) - that number determines the random menu items. */
            Random r = new Random();
            final int LOWER_BOUND = 0;
            final int UPPER_BOUND = 1;
            int randomNum = r.nextInt(UPPER_BOUND - LOWER_BOUND) + LOWER_BOUND;

			/* the following switch fills the menu with random items;
			 	a switch was used to avoid several chaining if statements*/
            switch (i) {
                case 0:
                    randMenu.setMenuEntree(entrees.get(randomNum));
                    break;
                case 1:
                    randMenu.setMenuSide(sides.get(randomNum));
                    break;
                case 2:
                    randMenu.setMenuSalad(salads.get(randomNum));
                    break;
                case 3:
                    randMenu.setMenuDessert(desserts.get(randomNum));
                    break;
                default:
                    break;
            }
        }
        return randMenu;
    }

    /**
     * Method minCaloriesMenu
     *
     * @param name a String
     * @return the minimum calorie of menu
     */
    public Menu minCaloriesMenu(String name) {

        Menu minMenu = new Menu(name);

        double tempPrice = 100000000000.0;
        Entree entreeMinCal = null;
        Iterator<Entree> itr1 = entrees.iterator();
        while (itr1.hasNext()) {
            Entree current = itr1.next();
            if (tempPrice > current.getPrice()) {
                tempPrice = current.getPrice();
                entreeMinCal = current;
            }
        }
        Side sideMinCal = null;
        Iterator<Side> itr2 = sides.iterator();
        while (itr2.hasNext()) {
            Side current = itr2.next();
            if (tempPrice > current.getPrice()) {
                tempPrice = current.getPrice();
                sideMinCal = current;
            }
        }
        Salad saladMinCal = null;
        Iterator<Salad> itr3 = salads.iterator();
        while (itr3.hasNext()) {
            Salad current = itr3.next();
            if (tempPrice > current.getPrice()) {
                tempPrice = current.getPrice();
                saladMinCal = current;
            }
        }
        Dessert dessertMinCal = null;
        Iterator<Dessert> itr4 = desserts.iterator();
        while (itr4.hasNext()) {
            Dessert current = itr4.next();
            if (tempPrice > current.getPrice()) {
                tempPrice = current.getPrice();
                dessertMinCal = current;
            }
        }
        minMenu.setMenuEntree(entreeMinCal);
        minMenu.setMenuSide(sideMinCal);
        minMenu.setMenuSalad(saladMinCal);
        minMenu.setMenuDessert(dessertMinCal);
        return minMenu;
    }

    /**
     * Method maxCaloriesMenu
     *
     * @param name a String
     * @return the minimum calorie of menu
     */
    public Menu maxCaloriesMenu(String name) {

        Menu maxMenu = new Menu(name);

        double tempPrice = 0.0;
        Entree entreeMaxCal = null;
        Iterator<Entree> itr5 = entrees.iterator();
        while (itr5.hasNext()) {
            Entree current = itr5.next();
            if (tempPrice < current.getPrice()) {
                tempPrice = current.getPrice();
                entreeMaxCal = current;
            }
        }
        Side sideMaxCal = null;
        Iterator<Side> itr6 = sides.iterator();
        while (itr6.hasNext()) {
            Side current = itr6.next();
            if (tempPrice < current.getPrice()) {
                tempPrice = current.getPrice();
                sideMaxCal = current;
            }
        }
        Salad saladMaxCal = null;
        Iterator<Salad> itr7 = salads.iterator();
        while (itr7.hasNext()) {
            Salad current = itr7.next();
            if (tempPrice < current.getPrice()) {
                tempPrice = current.getPrice();
                saladMaxCal = current;
            }
        }
        Dessert dessertMaxCal = null;
        Iterator<Dessert> itr8 = desserts.iterator();
        while (itr8.hasNext()) {
            Dessert current = itr8.next();
            if (tempPrice < current.getPrice()) {
                tempPrice = current.getPrice();
                dessertMaxCal = current;
            }
        }
        maxMenu.setMenuEntree(entreeMaxCal);
        maxMenu.setMenuSide(sideMaxCal);
        maxMenu.setMenuSalad(saladMaxCal);
        maxMenu.setMenuDessert(dessertMaxCal);
        return maxMenu;
    }

    public ArrayList<Entree> getEntrees() {
        return entrees;
    }

    public ArrayList<Side> getSides() {
        return sides;
    }

    public ArrayList<Salad> getSalads() {
        return salads;
    }

    public ArrayList<Dessert> getDesserts() {
        return desserts;
    }

    public void setEntrees(ArrayList<Entree> entrees) {
        this.entrees = entrees;
    }

    public void setSides(ArrayList<Side> sides) {
        this.sides = sides;
    }

    public void setDesserts(ArrayList<Dessert> desserts) {
        this.desserts = desserts;
    }

    public void setSalads(ArrayList<Salad> salads) {
        this.salads = salads;
    }
}
