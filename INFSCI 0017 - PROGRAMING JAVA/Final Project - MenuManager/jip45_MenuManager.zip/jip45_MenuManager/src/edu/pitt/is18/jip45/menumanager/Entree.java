package edu.pitt.is18.jip45.menumanager;

/**
 * Class Entree extends MenuItem
 *
 * @author Jing Pang
 * created: 10/27/2018
 * updated: 11/25/2018
 */
public class Entree extends MenuItem {

    /**
     * Constructor Entree(String, String, int, double)
     *
     * @param name        a String
     * @param description a String
     * @param calories    an integer number
     * @param price       an double number
     */
    public Entree(String name, String description, int calories, double price) {
        super(name, description, calories, price);
    }

}
