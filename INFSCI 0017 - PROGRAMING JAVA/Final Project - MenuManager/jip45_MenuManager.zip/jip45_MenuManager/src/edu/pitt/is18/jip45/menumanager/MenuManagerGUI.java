package edu.pitt.is18.jip45.menumanager;

import org.w3c.dom.events.MouseEvent;

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Class FileManager
 *
 * @author Jing Pang
 * created 11/25/2018
 */
public class MenuManagerGUI {

    /* Global variables representing SWING controls for the main frame */
    private JFrame mainFrame;
    private JPanel listPane;
    private JPanel buildYourOwnMenuPanel;
    private JPanel generateMenuPanel;
    private JPanel createdMenusPanel;
    private JPanel createPane;
    private JPanel panelBuildYourOwnMenu;
    private JPanel generateMenuRadioButtons;
    private JPanel menuOptionButtons;
    private JPanel createdMenusCheckBoxes;
    private JLabel jlblEntree;
    private JLabel jlblSide;
    private JLabel jlblSalad;
    private JLabel jlblDessert;
    private JLabel jlblCreatedMenu;
    private JComboBox jcboEntree;
    private JComboBox jcboSide;
    private JComboBox jcboSalad;
    private JComboBox jcboDessert;
    private JTextArea jtfCreateAMenu;
    private JButton jbtCreateMenu;
    private JButton jbtGenerateRandomMenu;
    private JButton jbtGenerateMinCalMenu;
    private JButton jbtGenerateMaxCalMenu;
    private JButton jbtDetails;
    private JButton jbtDeleteAll;
    private JButton jbtSave;

    /*
     * Global variables representing SWING controls for the secondary frame
     * This secondary window will show details of the Menu associated to the selected Menu name
     */
    private JFrame secondaryFrame;
    private JLabel jlblShowEntree;
    private JLabel jlblShowSide;
    private JLabel jlblShowSalad;
    private JLabel jlblShowDessert;
    private JLabel jlblShowCal;
    private JLabel jlblShowPrice;
    private JTextArea jtfShowEntree;
    private JTextArea jtfShowSide;
    private JTextArea jtfShowSalad;
    private JTextArea jtfShowDessert;
    private JTextArea jtfShowCal;
    private JTextArea jtfShowPrice;
    private JButton jbtHideWindow;

    /* This object controls accounts and customers. See class bank.Bank */
    private MenuManager menuManger;
    private Menu createMenu;
    private Menu showMenu;
    private ArrayList<Menu> existedMenus;

    /* Setup input and output file path */
    private final static String DISH_FILE = "data/dishes.txt";
    private final static String OUTPUT = "/Users/pangjing/IdeaProjects/ProgramJavaCourse/Assignments/jip45_FinalProject/jip45_MenuManager/data/menus.txt";

    // Launch the application.
    public static void main(String[] args) {
        MenuManagerGUI window = new MenuManagerGUI();
    }

    /**
     * Constructor MenuMangerGUI.
     */
    public MenuManagerGUI() {

        menuManger = new MenuManager(DISH_FILE);

        // default a few Menus shown in the list
        existedMenus = new ArrayList<>();
        Menu mondayMenu = menuManger.randomMenu("Menu for Monday");
        Menu tuesdayMenu = menuManger.randomMenu("Menu for Tuesday");
        Menu myOwnMenu = new Menu("My Own Menu");
        existedMenus.add(mondayMenu);
        existedMenus.add(myOwnMenu);
        existedMenus.add(tuesdayMenu);

        initMainFrame();
        initSecondaryFrame();
    }

    /**
     * Initialize the contents of the main frame.
     */
    private void initMainFrame() {
        // set ups the JFrame
        JFrame.setDefaultLookAndFeelDecorated(true);
        mainFrame = new JFrame("Menu Manager"); // the contructor allows to specify a title for the window
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // makes the program to end when the window is closed
        mainFrame.setResizable(true); // the window can be resizable
        mainFrame.setBounds(200, 100, 650, 400); // start in the position 200,200 o the screen and it is 800 pixels wide and 1000 pixels tall

        // Creates the control panel for three panels "Build your own Menu", "Or generate a Menu" and "Created Menus"
        buildYourOwnMenuPanel = buildYourOwnMenuComboBox();
        generateMenuPanel = generateMenuRadioButtons();
        createdMenusPanel = createdMenusCheckBoxes();

        // Create control panel
        mainFrame.getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 0;
        mainFrame.getContentPane().add(buildYourOwnMenuPanel, c);
        c.gridx = 0;
        c.gridy = 1;
        mainFrame.getContentPane().add(generateMenuPanel, c);
        c.fill = GridBagConstraints.BOTH;
        c.gridx = 1;
        c.gridy = 0;
        c.gridheight = 2;
        mainFrame.getContentPane().add(createdMenusPanel, c);
        mainFrame.setVisible(true);
    }

    /**
     * buildYourOwnMenuComboBox
     * Create a pane to display information containing as asked.
     *
     * @return a JPanel
     */
    private JPanel buildYourOwnMenuComboBox() {

        // import listpane
        listPane = listPane();
        // create a button with text "create menu with these dishes"
        jbtCreateMenu = new JButton("Create Menu with these dishes");
        jbtCreateMenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // show input dialog to ask input a Menu name
                String menuName = JOptionPane.showInputDialog("Please input a Menu name");
                // create a new Menu
                createMenu = new Menu(menuName);
                // set Menu Entree
                if (jcboEntree.getSelectedItem().equals("None")) createMenu.setMenuEntree(null);
                else createMenu.setMenuEntree((Entree) jcboEntree.getSelectedItem());
                // set Menu Side
                if (jcboSide.getSelectedItem().equals("None")) createMenu.setMenuSide(null);
                else createMenu.setMenuSide((Side) jcboSide.getSelectedItem());
                // set Menu Salad
                if (jcboSalad.getSelectedItem().equals("None")) createMenu.setMenuSalad(null);
                else createMenu.setMenuSalad((Salad) jcboSalad.getSelectedItem());
                // set Menu Dessert
                if (jcboDessert.getSelectedItem().equals("None")) createMenu.setMenuDessert(null);
                else createMenu.setMenuDessert((Dessert) jcboDessert.getSelectedItem());
                // add Menu to ArrayList<Menu> existedMenus
                existedMenus.add(createMenu);
                // link new Menu to JTextField to show created Menu.
                if (jtfCreateAMenu.getText().length() == 0) jtfCreateAMenu.setText(createMenu.toString());
                else {
                    jtfCreateAMenu.setText(jtfCreateAMenu.getText() + "\n" + createMenu.toString());
                }
            }
        });
        createPane = new JPanel();
        createPane.add(jbtCreateMenu);

        // combine both panels
        panelBuildYourOwnMenu = new JPanel();
        panelBuildYourOwnMenu.setLayout(new BoxLayout(panelBuildYourOwnMenu, BoxLayout.PAGE_AXIS));
        panelBuildYourOwnMenu.add(listPane);
        panelBuildYourOwnMenu.add(createPane);
        panelBuildYourOwnMenu.setBorder(new TitledBorder(new EtchedBorder(), "Build your own Menu"));

        return panelBuildYourOwnMenu;
    }

    /**
     * listPane
     * Create a listPane to present options of menus in Entrees, Sides, Salads and Desserts.
     * Also create a select pane to allow user change the desire option.
     *
     * @return a JPanel
     */
    private JPanel listPane() {
        // group of "build your own menu"
        // create a label with text "Entree:"
        jlblEntree = new JLabel("Entree:");
        // create a combo box with entrees
        jcboEntree = new JComboBox();
        // note how the bounds are set according to the X Y and width of another component
        //jcboEntree.setBounds(jlblEntree.getX() + jlblEntree.getWidth() + 2, jlblEntree.getY(), 40, 15);
        // entrees in combo box
        for (Entree entree : menuManger.getEntrees()) {
            jcboEntree.addItem(entree);
        }
        // add an extra option in combo box
        jcboEntree.addItem("None");

        // create a label with text "Side:"
        jlblSide = new JLabel("Side:");
        // create a combo box with entrees
        jcboSide = new JComboBox();
        // note how the bounds are set according to the X Y and width of another component
        //jcboSide.setBounds(jlblSide.getX() + jlblSide.getWidth() + 2, jlblSide.getY(), 40, 15);
        // entrees in combo box
        for (Side side : menuManger.getSides()) {
            jcboSide.addItem(side);
        }
        // add an extra option in combo box
        jcboSide.addItem("None");

        // create a label with text "Salad:"
        jlblSalad = new JLabel("Salad:");
        // create a combo box with entrees
        jcboSalad = new JComboBox();
        // note how the bounds are set according to the X Y and width of another component
        //jcboSalad.setBounds(jlblSalad.getX() + jlblSalad.getWidth() + 2, jlblSalad.getY(), 40, 15);
        // entrees in combo box
        for (Salad salad : menuManger.getSalads()) {
            jcboSalad.addItem(salad);
        }
        // add an extra option in combo box
        jcboSalad.addItem("None");

        // create a label with text "Dessert:"
        jlblDessert = new JLabel("Dessert:");
        // create a combo box with entrees
        jcboDessert = new JComboBox();
        // note how the bounds are set according to the X Y and width of another component
        //jcboDessert.setBounds(jlblDessert.getX() + jlblDessert.getWidth() + 2, jlblDessert.getY(), 40, 15);
        // entrees in combo box
        for (Dessert dessert : menuManger.getDesserts()) {
            jcboDessert.addItem(dessert);
        }
        // add an extra option in combo box
        jcboDessert.addItem("None");

        listPane = new JPanel();
        listPane.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        listPane.add(jlblEntree, gbc);
        gbc.gridx = 1;
        gbc.gridy = 0;
        listPane.add(jcboEntree, gbc);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 1;
        listPane.add(jlblSide, gbc);
        gbc.gridx = 1;
        gbc.gridy = 1;
        listPane.add(jcboSide, gbc);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 2;
        listPane.add(jlblSalad, gbc);
        gbc.gridx = 1;
        gbc.gridy = 2;
        listPane.add(jcboSalad, gbc);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 3;
        listPane.add(jlblDessert, gbc);
        gbc.gridx = 1;
        gbc.gridy = 3;
        listPane.add(jcboDessert, gbc);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0.0;
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 4;
        return listPane;
    }

    /**
     * generateMenuRadioButtons
     * Create three buttons presenting options to let system randomly creating Menu or generating the minimum
     * or maximum calories of Menus
     *
     * @return a JPanel
     */
    private JPanel generateMenuRadioButtons() {

        // create a button with text "create menu with these dishes"
        jbtGenerateRandomMenu = new JButton("Generate a Random Menu");
        jbtGenerateRandomMenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String menuName = JOptionPane.showInputDialog("Please input a Menu name");
                Menu temp = menuManger.randomMenu(menuName);
                existedMenus.add(temp);
                if (jtfCreateAMenu.getText().length() == 0) jtfCreateAMenu.setText(temp.toString());
                else {
                    jtfCreateAMenu.setText(jtfCreateAMenu.getText() + "\n" + temp.toString());
                }
            }
        });

        // create a button with text "create menu with these dishes"
        jbtGenerateMinCalMenu = new JButton("Generate a Minimum Calories Menu");
        jbtGenerateMinCalMenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String menuName = JOptionPane.showInputDialog("Please input a Menu name");
                Menu temp = menuManger.minCaloriesMenu(menuName);
                existedMenus.add(temp);
                if (jtfCreateAMenu.getText().length() == 0) jtfCreateAMenu.setText(temp.toString());
                else {
                    jtfCreateAMenu.setText(jtfCreateAMenu.getText() + "\n" + temp.toString());
                }
            }
        });

        // create a button with text "create menu with these dishes"
        jbtGenerateMaxCalMenu = new JButton("Generate a Maximum Calories Menu");
        jbtGenerateMaxCalMenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String menuName = JOptionPane.showInputDialog("Please input a Menu name");
                Menu temp = menuManger.maxCaloriesMenu(menuName);
                existedMenus.add(temp);
                if (jtfCreateAMenu.getText().length() == 0) jtfCreateAMenu.setText(temp.toString());
                else {
                    jtfCreateAMenu.setText(jtfCreateAMenu.getText() + "\n" + temp.toString());
                }
            }
        });

        generateMenuRadioButtons = new JPanel();
        generateMenuRadioButtons.setLayout(new GridLayout(3, 1));
        generateMenuRadioButtons.add(jbtGenerateRandomMenu);
        generateMenuRadioButtons.add(jbtGenerateMinCalMenu);
        generateMenuRadioButtons.add(jbtGenerateMaxCalMenu);
        generateMenuRadioButtons.setBorder(new TitledBorder(new EtchedBorder(), "Or generate a Menu"));

        return generateMenuRadioButtons;
    }

    /**
     * createdMenusCheckBoxes
     * Create a pane to display created Menus in ordered. Also, it provide three buttons.
     * One is providing a option to user to see details of the Menu that user selected,
     * the second one is deleting all displaying Menus,
     * and the third one is presenting a option to save all created Menus into a file.
     *
     * @return a JPanel
     */
    private JPanel createdMenusCheckBoxes() {
        // create a lable of menus check box
        jlblCreatedMenu = new JLabel("Created Menus:", JLabel.LEFT);

        // create a text field for the created menus
        jtfCreateAMenu = new JTextArea(18, 25);
        jtfCreateAMenu.setEditable(false);
        jtfCreateAMenu.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent mouseEvent) {
                jtfCreateAMenu.setCursor(new Cursor(Cursor.TEXT_CURSOR));
            }

            public void mouseExited(MouseEvent mouseEvent) {
                jtfCreateAMenu.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        });
        jtfCreateAMenu.getCaret().addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                jtfCreateAMenu.getCaret().setVisible(true);
            }
        });
        jtfCreateAMenu.setText(existedMenus.get(0) + "\n" + existedMenus.get(1).getMenuName() + "\n" + existedMenus.get(2).getMenuName());
        JScrollPane jsp = new JScrollPane(jtfCreateAMenu, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        // create a pane of existence menu
        createdMenusPanel = new JPanel();
        createdMenusPanel.setBorder(new TitledBorder(new EtchedBorder()));
        createdMenusPanel.add(jsp);

        // create buttons of menu options
        jbtDetails = new JButton("Details");
        jbtDetails.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (jtfCreateAMenu.getSelectedText() != null) {
                    String tempString = jtfCreateAMenu.getSelectedText();
                    for (Menu tempMenu : existedMenus) {
                        if (tempMenu.toString().equals(tempString)) {
                            showMenu = tempMenu;
                            jtfShowEntree.setText(showMenu.getMenuEntree().getDescription());
                            jtfShowSide.setText(showMenu.getMenuSide().getDescription());
                            jtfShowSalad.setText(showMenu.getMenuSalad().getDescription());
                            jtfShowDessert.setText(showMenu.getMenuDessert().getDescription());
                            jtfShowCal.setText("" + showMenu.totalCalories());
                            jtfShowPrice.setText("" + showMenu.totalPrice());
                            secondaryFrame.setVisible(true); // display the new window
                        }
                    }
                }
            }
        });
        jbtDeleteAll = new JButton("Delete all");
        jbtDeleteAll.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jtfCreateAMenu.setText("");
                existedMenus.clear();
            }
        });
        jbtSave = new JButton("Save to file");
        jbtSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                File outputFile = new File(OUTPUT);
                if (!outputFile.exists()) {
                    try {
                        outputFile.createNewFile();

                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
                FileManager.writeMenu(OUTPUT, existedMenus);
            }
        });

        menuOptionButtons = new JPanel();
        menuOptionButtons.setLayout(new BoxLayout(menuOptionButtons, BoxLayout.X_AXIS));
        menuOptionButtons.add(jbtDetails);
        menuOptionButtons.add(jbtDeleteAll);
        menuOptionButtons.add(jbtSave);

        createdMenusCheckBoxes = new JPanel();
        createdMenusCheckBoxes.setLayout(new BorderLayout());
        createdMenusCheckBoxes.add(jlblCreatedMenu, BorderLayout.PAGE_START);
        createdMenusCheckBoxes.add(createdMenusPanel, BorderLayout.CENTER);
        createdMenusCheckBoxes.add(menuOptionButtons, BorderLayout.PAGE_END);

        return createdMenusCheckBoxes;
    }

    /**
     * Initialize the contents of the secondary frame.
     */
    private void initSecondaryFrame() {
        secondaryFrame = new JFrame("Menu:  My Own Menu");
        secondaryFrame.setBounds(200, 100, 800, 600);
        secondaryFrame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        secondaryFrame.getContentPane().setLayout(null);
        secondaryFrame.setVisible(false);

        jlblShowEntree = new JLabel("Entree: ");
        jlblShowSide = new JLabel("Side: ");
        jlblShowSalad = new JLabel("Salad: ");
        jlblShowDessert = new JLabel("Dessert: ");
        jlblShowCal = new JLabel("Total calories: ");
        jlblShowPrice = new JLabel("Total Price: ");
        jtfShowEntree = new JTextArea("");
        jtfShowEntree.setLineWrap(true);
        jtfShowSide = new JTextArea("");
        jtfShowSalad = new JTextArea("");
        jtfShowDessert = new JTextArea("");
        jtfShowCal = new JTextArea("");
        jtfShowPrice = new JTextArea("");

        // positioning all labels and text fields
        jlblShowEntree.setBounds(10, 10, 600, 90);
        jlblShowSide.setBounds(10, 120, 600, 90);
        jlblShowSalad.setBounds(10, 230, 600, 90);
        jlblShowDessert.setBounds(10, 330, 600, 90);
        jlblShowCal.setBounds(10, 430, 600, 30);
        jlblShowPrice.setBounds(10, 470, 600, 30);

        jtfShowEntree.setBounds(150, 10, 600, 90);
        jtfShowSide.setBounds(150, 120, 600, 90);
        jtfShowSalad.setBounds(150, 230, 600, 90);
        jtfShowDessert.setBounds(150, 330, 600, 90);
        jtfShowCal.setBounds(150, 435, 600, 20);
        jtfShowPrice.setBounds(150, 475, 600, 20);
        // Make the text field not editable (display text,but user can not change it)
        jtfShowEntree.setEditable(false);
        jtfShowSide.setEditable(false);
        jtfShowSalad.setEditable(false);
        jtfShowDessert.setEditable(false);

        jbtHideWindow = new JButton("Hide This Window");
        jbtHideWindow.setBounds(450, 550, 200, 30);
        jbtHideWindow.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                secondaryFrame.setVisible(false); // close the window
            }
        });

        secondaryFrame.add(jlblShowEntree);
        secondaryFrame.add(jlblShowSide);
        secondaryFrame.add(jlblShowSalad);
        secondaryFrame.add(jlblShowDessert);
        secondaryFrame.add(jlblShowCal);
        secondaryFrame.add(jlblShowPrice);
        secondaryFrame.add(jtfShowEntree);
        secondaryFrame.add(jtfShowSide);
        secondaryFrame.add(jtfShowSalad);
        secondaryFrame.add(jtfShowDessert);
        secondaryFrame.add(jtfShowCal);
        secondaryFrame.add(jtfShowPrice);
        secondaryFrame.add(jbtHideWindow);
    }
}
