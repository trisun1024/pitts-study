package edu.pitt.is18.jip45.menumanager;

/**
 * Class Side
 *
 * @author Jing Pang
 * created: 11/25/2018
 */

public class MenuItem {

    private String name;
    private String description;
    private int calories;
    private double price;

    /**
     * Constructor MenuItem(String, String, int, double)
     *
     * @param name        a String
     * @param description a String
     * @param calories    an integer number
     * @param price       an double number
     */
    public MenuItem(String name, String description, int calories, double price) {
        this.name = name;
        this.description = description;
        this.calories = calories;
        this.price = price;
    }

    // The following are getters and setters for the variables defined above;

    /**
     * Setter the menuitem's name to certain input name
     *
     * @param name a string
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Setter the menuitem's description to certain input description
     *
     * @param desc a string
     */
    public void setDescription(String desc) {
        this.description = desc;
    }

    /**
     * Setter the menuitem's calorie to certain input calorie
     *
     * @param cal a int
     */
    public void setCalories(int cal) {
        this.calories = cal;
    }

    /**
     * Setter the menuitem's price to certain input price
     *
     * @param price a double
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * Getter the menuitem's name
     *
     * @return a string
     */
    public String getName() {
        return this.name;
    }

    /**
     * Get the menuitem's name
     *
     * @return a string
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Getter the menuitem's name
     *
     * @return a int
     */
    public int getCalories() {
        return this.calories;
    }

    /**
     * Getter the menuitem's name
     *
     * @return a double
     */
    public double getPrice() {
        return this.price;
    }

    // Override toString() in order to return the name attribute.

    /**
     * Getter the menuitem's name
     *
     * @return a string
     */
    @Override
    public String toString() {
        return name;
    }
}
