# README

This part contains our success built Jar package with related name. There is also a sh file about how to run all this programs in advance.