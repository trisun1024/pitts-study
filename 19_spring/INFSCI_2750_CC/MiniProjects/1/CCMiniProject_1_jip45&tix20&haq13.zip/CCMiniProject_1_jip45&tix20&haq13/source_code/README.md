# README

This part is java source code of part 3 and part 4. This includes n-gram and customerized mapreduce java program for answering part 4.